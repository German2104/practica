"""LLM communication layer."""
