"""Prediction and attribution components."""
